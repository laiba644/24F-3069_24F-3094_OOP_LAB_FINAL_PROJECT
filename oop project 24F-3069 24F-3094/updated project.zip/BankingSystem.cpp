#include "Stronghold.h"

// Constructor - Initialize variables as declared in the header
CentralBank::CentralBank() {
    totalLoans = 0;       // Changed from outstandingDebt
    scamsFound = 0;       // Changed from corruptionCases
}

// Inspect financial records (now takes Finance& instead of Treasury&)
void CentralBank::inspectBooks(Finance& economy) {
    cout << "\n=== Royal Audit ===\n";

    int currentGoldReserves = economy.getGold();  // Changed from getGoldReserves()

    if (currentGoldReserves < 0) {
        cout << "EMBEZZLEMENT DISCOVERED! Treasury in deficit.\n";
        scamsFound++;  // Changed from corruptionCases++
    }
    else if (currentGoldReserves < 150) {
        cout << "Warning: Treasury dangerously low at " << currentGoldReserves << " gold.\n";
    }
    else {
        cout << "Treasury in good standing with " << currentGoldReserves << " gold.\n";
    }
}

// Grant a loan (now takes Finance& instead of Treasury&)
void CentralBank::grantLoan(Finance& economy, int sum) {  // Changed amount to sum
    cout << "\nProcessing loan for " << sum << " gold...\n";

    if (sum <= 0) {
        cout << "Loan rejected - invalid amount.\n";
        return;
    }

    economy.takeLoan(sum);  // Changed from acceptLoan()
    totalLoans += sum;      // Changed from outstandingDebt
    cout << sum << " gold loan approved. Total debt: " << totalLoans << "\n";
}

// Collect debt repayment (now takes Finance& instead of Treasury&)
void CentralBank::collectDebt(Finance& economy, int payment) {
    cout << "\nAttempting debt payment of " << payment << " gold...\n";

    if (payment <= 0 || payment > totalLoans) {  // Changed from outstandingDebt
        cout << "Invalid payment amount.\n";
        return;
    }

    if (payment > economy.getGold()) {  // Changed from getGoldReserves()
        cout << "Payment failed - insufficient funds.\n";
        return;
    }

    economy.makePayment(payment);  // Changed from repayDebt()
    totalLoans -= payment;         // Changed from outstandingDebt
    cout << payment << " gold applied to debt. Remaining: " << totalLoans << "\n";
}

// Display bank status (updated variable names)
void CentralBank::displayBankStatus() const {
    cout << "\n=== Royal Bank Ledger ===\n";
    cout << "Total Loans: " << totalLoans << " gold\n";  // Changed from Outstanding Debt
    cout << "Scams Found: " << scamsFound << "\n";       // Changed from Corruption Cases
}

// Save game data (updated variable names)
void CentralBank::saveGame() const {
    ofstream bankRecords("bank_ledger.dat");
    if (!bankRecords) {
        cout << "Failed to save bank records!\n";
        return;
    }

    bankRecords << totalLoans << endl << scamsFound;  // Changed variables
    bankRecords.close();
    cout << "Bank records secured.\n";
}

// Load game data (updated variable names)
void CentralBank::loadGame() {
    ifstream bankRecords("bank_ledger.dat");
    if (!bankRecords) {
        cout << "No bank records found!\n";
        return;
    }

    bankRecords >> totalLoans >> scamsFound;  // Changed variables
    bankRecords.close();
    cout << "Bank records restored.\n";
}